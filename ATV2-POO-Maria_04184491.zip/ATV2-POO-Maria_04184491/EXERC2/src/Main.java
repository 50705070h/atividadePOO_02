public class Main {
    public static void main(String[] args) {
        Carro c1 = new Carro("Tesla", 2022);

        System.out.println("Marca: " + c1.getMarca());
        System.out.println("Ano: " + c1.getAno());
    }
}
